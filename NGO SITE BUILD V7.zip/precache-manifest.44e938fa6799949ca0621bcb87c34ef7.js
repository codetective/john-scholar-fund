self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "88e4b5ea80da440463735147e1970321",
    "url": "/index.html"
  },
  {
    "revision": "f7487d214921848179d7",
    "url": "/static/css/2.4707e12a.chunk.css"
  },
  {
    "revision": "da6f8889e502875e9d38",
    "url": "/static/css/main.321a896f.chunk.css"
  },
  {
    "revision": "f7487d214921848179d7",
    "url": "/static/js/2.f9d0fd51.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/static/js/2.f9d0fd51.chunk.js.LICENSE.txt"
  },
  {
    "revision": "da6f8889e502875e9d38",
    "url": "/static/js/main.50d7a143.chunk.js"
  },
  {
    "revision": "2d2dba2503ba4b43402fdad5132f2053",
    "url": "/static/js/main.50d7a143.chunk.js.LICENSE.txt"
  },
  {
    "revision": "50652390ab4388be8644",
    "url": "/static/js/runtime-main.ffa6f8d7.js"
  },
  {
    "revision": "2f30e6aa7fe46f0004c97213d887dba5",
    "url": "/static/media/coin.2f30e6aa.svg"
  },
  {
    "revision": "407827a42e395f675856eaeebe7d241d",
    "url": "/static/media/facebook.407827a4.svg"
  },
  {
    "revision": "4fcc5e1cf6933e5631a6670d520f455b",
    "url": "/static/media/founder.4fcc5e1c.jpeg"
  },
  {
    "revision": "eb17d9ae719e74f7abb8b3c5d90dc6dc",
    "url": "/static/media/header_resized.eb17d9ae.jpg"
  },
  {
    "revision": "82e49ccd84aac5c46af452f346445956",
    "url": "/static/media/logo.82e49ccd.png"
  },
  {
    "revision": "755cda46d61e8c113921add132333c33",
    "url": "/static/media/mail.755cda46.svg"
  },
  {
    "revision": "36d3cded1bc6f0a00aebcc34b3f1873b",
    "url": "/static/media/news.36d3cded.jpeg"
  },
  {
    "revision": "70f3a7311ac5ce7c3d53cd2e52a947d6",
    "url": "/static/media/old-telephone-ringing.70f3a731.svg"
  },
  {
    "revision": "d5b607867d486a9787162b24f9367fef",
    "url": "/static/media/p1.d5b60786.jpg"
  },
  {
    "revision": "f8b8826c6edcefc3f1c8fca7af59640f",
    "url": "/static/media/p2.f8b8826c.jpg"
  },
  {
    "revision": "e4b360f80708b5aa304ec63837d720a8",
    "url": "/static/media/pumoren2.e4b360f8.jpeg"
  },
  {
    "revision": "0b0155c70410d39296a5dc4ce8e480dc",
    "url": "/static/media/share.0b0155c7.svg"
  },
  {
    "revision": "a1859e4062fb25a4325e90f4c8cc358b",
    "url": "/static/media/twitter.a1859e40.svg"
  }
]);